This project was bootstrapped with [Create React App](https://github.com/facebook/create-react-app).

Instructions to run the application.

1) Clone the project.
2) Run "npm install".
3) To install axios, "npm install axios".
4) To install react table, "npm install react-table"
5) For bypassing CORS issue, please visit - https://cors-anywhere.herokuapp.com/corsdemo and click on "Request temporary access to the demo server button"  


