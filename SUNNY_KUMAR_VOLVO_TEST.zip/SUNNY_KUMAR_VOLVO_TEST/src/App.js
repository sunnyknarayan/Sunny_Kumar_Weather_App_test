import React, { Component } from 'react'
import axios from 'axios'
import ReactTable from "react-table";
import 'react-table/react-table.css'

export default class App extends Component {

  constructor(props) {
    super(props)
    this.finalData = [];
    this.state = {
      cities: [],
    }
  }


  // making the API calls to get the required response to display in UI
  async getCityData(city) {

    // Prepend "https://cors-anywhere.herokuapp.com" to each API call, to bypass the CORS issue.
    
    const [firstResponse] = await Promise.all([
      axios.get(`https://cors-anywhere.herokuapp.com/http://www.metaweather.com/api/location/search/?query=` + city) // dynamic city name is being passed
    ])

    const [secondResponse] = await Promise.all([
      axios.get(`https://cors-anywhere.herokuapp.com/https://www.metaweather.com/api/location/` + firstResponse.data[0].woeid + `/`) // woeid captured from firstresponse for the respective city
    ])

    const [thirdResponse] = await Promise.all([
      axios.get(`https://cors-anywhere.herokuapp.com/https://www.metaweather.com/static/img/weather/png/64/` + secondResponse.data.consolidated_weather[1].weather_state_abbr + `.png`) 
      // consolidated_weather data is getting data for 6 days in sequence. To get tomorrow's data, used 1 to capture tomorrow's data based on index
      // 0 is for today, 1 for tomorrow, 2 for day after tomorrow etc.
    ])

    // creating the object for each city, based on the above responses
    var object = {
      "title": city,
      "weather_state_name": secondResponse.data.consolidated_weather[1].weather_state_name,
      "weather_state_abbr": <img src={thirdResponse.config.url} />,
      "max_temp": Math.round(secondResponse.data.consolidated_weather[1].max_temp),
      "min_temp": Math.round(secondResponse.data.consolidated_weather[1].min_temp)
    }
    this.finalData.push(object);

    // Updating the state to render in UI
    this.setState({
      cities: this.finalData
    });
  }

  // componentDidMount() is a hook that gets invoked right after a React component has been mounted, to render data in UI 
  componentDidMount() {
    var cities = ["london", "berlin", "new york", "gothenburg", "stockholm", "mountain view"];  //   // list of cities to display weather report
    cities.map((city) => {
      console.log("each city : ", city);
      this.getCityData(city);  
      return true;
    })
  }


  render() {
    // columns values to dispaly in Reacttable
    const columns = [
      {
        Header: "LIVE WEATHER FORECAST",
        columns: [{
          Header: 'City',
          accessor: 'title',
        }
          , {
          Header: 'Weather',
          accessor: 'weather_state_name',
        }
          , {
          Header: 'Weather View',
          accessor: 'weather_state_abbr',
        }
          , {
          Header: 'Max Temperature',
          accessor: 'max_temp',
        }
          , {
          Header: 'Min Temperature',
          accessor: 'min_temp',
        }]
      }
    ]

    return (
      <ReactTable
        data={this.state.cities}
        columns={columns}
      />
    )
  }
}

